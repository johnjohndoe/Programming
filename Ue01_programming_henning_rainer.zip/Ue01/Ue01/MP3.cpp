#include "StdAfx.h"
#include "MP3.h"
#include "id3/tag.h"

MP3::MP3(const string& filename)
{
	ID3_Tag id3Tag(filename.c_str());
	
   ID3_Tag::Iterator* iter = id3Tag.CreateIterator();
   ID3_Frame* myFrame = NULL;

   while (NULL != (myFrame = iter->GetNext()))
   {
		ID3_Field* myField = myFrame->GetField(ID3FN_TEXT);;

		if (myField != NULL)
		{
			if (myField->GetEncoding() == 0) // Skip Unicode
			{
				switch(myFrame->GetID())
				{
				case ID3FID_ALBUM:
					mAlbum = myField->GetRawText();
					break;
				case ID3FID_TITLE:
					mTitle = myField->GetRawText();
					break;
				case ID3FID_LEADARTIST:
					mArtist = myField->GetRawText();
					break;
				case ID3FID_CONTENTTYPE:
					mGenre = myField->GetRawText();
					break;

				default:
					break;
				}
			}
		}
   }
   mFilename = filename;
   
}

MP3::~MP3(void)
{
}
