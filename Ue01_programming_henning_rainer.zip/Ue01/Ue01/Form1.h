#pragma once
#include "MP3.h"
#include <msclr/marshal_cppstd.h> 

namespace Ue01 {

	using namespace System;
	using namespace System::ComponentModel;
	using namespace System::Collections;
	using namespace System::Windows::Forms;
	using namespace System::Data;
	using namespace System::Drawing;

	/// <summary>
	/// Zusammenfassung f�r Form1
	///
	/// Warnung: Wenn Sie den Namen dieser Klasse �ndern, m�ssen Sie auch
	///          die Ressourcendateiname-Eigenschaft f�r das Tool zur Kompilierung verwalteter Ressourcen �ndern,
	///          das allen RESX-Dateien zugewiesen ist, von denen diese Klasse abh�ngt.
	///          Anderenfalls k�nnen die Designer nicht korrekt mit den lokalisierten Ressourcen
	///          arbeiten, die diesem Formular zugewiesen sind.
	/// </summary>
	public ref class Form1 : public System::Windows::Forms::Form
	{
	public:
		Form1(void)
		{
			InitializeComponent();
			//
			//TODO: Konstruktorcode hier hinzuf�gen.
			//
		}

	protected:
		/// <summary>
		/// Verwendete Ressourcen bereinigen.
		/// </summary>
		~Form1()
		{
			if (components)
			{
				delete components;
			}
		}
	private: System::Windows::Forms::FolderBrowserDialog^  folderBrowserDialog_Mp3;
	private: System::Windows::Forms::ListView^  listView_Mp3;
	protected: 

	private: System::Windows::Forms::ColumnHeader^  columnHeader_Filename;
	private: System::Windows::Forms::ColumnHeader^  columnHeader_Title;
	private: System::Windows::Forms::ColumnHeader^  columnHeader_Artists;
	private: System::Windows::Forms::ColumnHeader^  columnHeader_Album;
	private: System::Windows::Forms::ColumnHeader^  columnHeader_Genre;
	private: System::Windows::Forms::MenuStrip^  menuStrip1;
	private: System::Windows::Forms::ToolStripMenuItem^  dateiToolStripMenuItem;
	private: System::Windows::Forms::ToolStripMenuItem^  ordnerW�hlenToolStripMenuItem;
	private: System::Windows::Forms::ToolStripMenuItem^  beendenToolStripMenuItem;
	private: System::Windows::Forms::OpenFileDialog^  openFileDialog_mp3;
	private: System::Windows::Forms::ToolStripMenuItem^  dateien�ffnenToolStripMenuItem;



	private:
		/// <summary>
		/// Erforderliche Designervariable.
		/// </summary>
		System::ComponentModel::Container ^components;

#pragma region Windows Form Designer generated code
		/// <summary>
		/// Erforderliche Methode f�r die Designerunterst�tzung.
		/// Der Inhalt der Methode darf nicht mit dem Code-Editor ge�ndert werden.
		/// </summary>
		void InitializeComponent(void)
		{
			this->folderBrowserDialog_Mp3 = (gcnew System::Windows::Forms::FolderBrowserDialog());
			this->listView_Mp3 = (gcnew System::Windows::Forms::ListView());
			this->columnHeader_Filename = (gcnew System::Windows::Forms::ColumnHeader());
			this->columnHeader_Title = (gcnew System::Windows::Forms::ColumnHeader());
			this->columnHeader_Artists = (gcnew System::Windows::Forms::ColumnHeader());
			this->columnHeader_Album = (gcnew System::Windows::Forms::ColumnHeader());
			this->columnHeader_Genre = (gcnew System::Windows::Forms::ColumnHeader());
			this->menuStrip1 = (gcnew System::Windows::Forms::MenuStrip());
			this->dateiToolStripMenuItem = (gcnew System::Windows::Forms::ToolStripMenuItem());
			this->dateien�ffnenToolStripMenuItem = (gcnew System::Windows::Forms::ToolStripMenuItem());
			this->ordnerW�hlenToolStripMenuItem = (gcnew System::Windows::Forms::ToolStripMenuItem());
			this->beendenToolStripMenuItem = (gcnew System::Windows::Forms::ToolStripMenuItem());
			this->openFileDialog_mp3 = (gcnew System::Windows::Forms::OpenFileDialog());
			this->menuStrip1->SuspendLayout();
			this->SuspendLayout();
			// 
			// listView_Mp3
			// 
			this->listView_Mp3->Columns->AddRange(gcnew cli::array< System::Windows::Forms::ColumnHeader^  >(5) {this->columnHeader_Filename, 
				this->columnHeader_Title, this->columnHeader_Artists, this->columnHeader_Album, this->columnHeader_Genre});
			this->listView_Mp3->Dock = System::Windows::Forms::DockStyle::Fill;
			this->listView_Mp3->Location = System::Drawing::Point(0, 24);
			this->listView_Mp3->Name = L"listView_Mp3";
			this->listView_Mp3->Size = System::Drawing::Size(1030, 477);
			this->listView_Mp3->TabIndex = 0;
			this->listView_Mp3->UseCompatibleStateImageBehavior = false;
			this->listView_Mp3->View = System::Windows::Forms::View::Details;
			// 
			// columnHeader_Filename
			// 
			this->columnHeader_Filename->Text = L"Dateiname";
			this->columnHeader_Filename->Width = 249;
			// 
			// columnHeader_Title
			// 
			this->columnHeader_Title->Text = L"Titel";
			this->columnHeader_Title->Width = 193;
			// 
			// columnHeader_Artists
			// 
			this->columnHeader_Artists->Text = L"Interpret";
			this->columnHeader_Artists->Width = 174;
			// 
			// columnHeader_Album
			// 
			this->columnHeader_Album->Text = L"Album";
			this->columnHeader_Album->Width = 166;
			// 
			// columnHeader_Genre
			// 
			this->columnHeader_Genre->Text = L"Genre";
			this->columnHeader_Genre->Width = 130;
			// 
			// menuStrip1
			// 
			this->menuStrip1->Items->AddRange(gcnew cli::array< System::Windows::Forms::ToolStripItem^  >(1) {this->dateiToolStripMenuItem});
			this->menuStrip1->Location = System::Drawing::Point(0, 0);
			this->menuStrip1->Name = L"menuStrip1";
			this->menuStrip1->Size = System::Drawing::Size(1030, 24);
			this->menuStrip1->TabIndex = 1;
			this->menuStrip1->Text = L"menuStrip1";
			// 
			// dateiToolStripMenuItem
			// 
			this->dateiToolStripMenuItem->DropDownItems->AddRange(gcnew cli::array< System::Windows::Forms::ToolStripItem^  >(3) {this->dateien�ffnenToolStripMenuItem, 
				this->ordnerW�hlenToolStripMenuItem, this->beendenToolStripMenuItem});
			this->dateiToolStripMenuItem->Name = L"dateiToolStripMenuItem";
			this->dateiToolStripMenuItem->Size = System::Drawing::Size(44, 20);
			this->dateiToolStripMenuItem->Text = L"&Datei";
			// 
			// dateien�ffnenToolStripMenuItem
			// 
			this->dateien�ffnenToolStripMenuItem->Name = L"dateien�ffnenToolStripMenuItem";
			this->dateien�ffnenToolStripMenuItem->Size = System::Drawing::Size(165, 22);
			this->dateien�ffnenToolStripMenuItem->Text = L"Datei(en) �ffnen";
			this->dateien�ffnenToolStripMenuItem->Click += gcnew System::EventHandler(this, &Form1::dateien�ffnenToolStripMenuItem_Click);
			// 
			// ordnerW�hlenToolStripMenuItem
			// 
			this->ordnerW�hlenToolStripMenuItem->Name = L"ordnerW�hlenToolStripMenuItem";
			this->ordnerW�hlenToolStripMenuItem->Size = System::Drawing::Size(165, 22);
			this->ordnerW�hlenToolStripMenuItem->Text = L"&Ordner w�hlen";
			this->ordnerW�hlenToolStripMenuItem->Click += gcnew System::EventHandler(this, &Form1::ordnerW�hlenToolStripMenuItem_Click);
			// 
			// beendenToolStripMenuItem
			// 
			this->beendenToolStripMenuItem->Name = L"beendenToolStripMenuItem";
			this->beendenToolStripMenuItem->Size = System::Drawing::Size(165, 22);
			this->beendenToolStripMenuItem->Text = L"&Beenden";
			this->beendenToolStripMenuItem->Click += gcnew System::EventHandler(this, &Form1::beendenToolStripMenuItem_Click);
			// 
			// openFileDialog_mp3
			// 
			this->openFileDialog_mp3->DefaultExt = L"*.mp3";
			this->openFileDialog_mp3->Filter = L"Musikdateien|*.mp3";
			this->openFileDialog_mp3->Multiselect = true;
			this->openFileDialog_mp3->RestoreDirectory = true;
			this->openFileDialog_mp3->Title = L"Musikdatei ausw�hlen";
			// 
			// Form1
			// 
			this->AutoScaleDimensions = System::Drawing::SizeF(6, 13);
			this->AutoScaleMode = System::Windows::Forms::AutoScaleMode::Font;
			this->ClientSize = System::Drawing::Size(1030, 501);
			this->Controls->Add(this->listView_Mp3);
			this->Controls->Add(this->menuStrip1);
			this->MainMenuStrip = this->menuStrip1;
			this->Name = L"Form1";
			this->Text = L"Form1";
			this->menuStrip1->ResumeLayout(false);
			this->menuStrip1->PerformLayout();
			this->ResumeLayout(false);
			this->PerformLayout();

		}
#pragma endregion
	private: System::Void beendenToolStripMenuItem_Click(System::Object^  sender, System::EventArgs^  e) {

				 Application::Exit();
			 }
private: System::Void ordnerW�hlenToolStripMenuItem_Click(System::Object^  sender, System::EventArgs^  e) {

			 if (folderBrowserDialog_Mp3->ShowDialog() == System::Windows::Forms::DialogResult::OK)
			 {
				System::IO::DirectoryInfo^ dirInfo = gcnew System::IO::DirectoryInfo(folderBrowserDialog_Mp3->SelectedPath);
			
				array<System::IO::FileInfo^>^ files = dirInfo->GetFiles("*.mp3");

				listView_Mp3->Items->Clear();

				for (int i = 0; i < files->Length; ++i)
				{
					
					MP3* mp3 = new MP3(
						msclr::interop::marshal_as<std::string>(files[i]->FullName)
						);

					ListViewItem^ row = gcnew ListViewItem(gcnew String(mp3->mFilename.c_str()));
					row->SubItems->Add(gcnew String(mp3->mArtist.c_str()));
					row->SubItems->Add(gcnew String(mp3->mTitle.c_str()));
					row->SubItems->Add(gcnew String(mp3->mAlbum.c_str()));
					row->SubItems->Add(gcnew String(mp3->mGenre.c_str()));

					listView_Mp3->Items->Add(row);

					delete mp3;

				}

				
				
			 }
		 }
private: System::Void dateien�ffnenToolStripMenuItem_Click(System::Object^  sender, System::EventArgs^  e) {

		
			 if (openFileDialog_mp3->ShowDialog() == System::Windows::Forms::DialogResult::OK)
			 {
				
			 listView_Mp3->Items->Clear();

				for (int i = 0; i < openFileDialog_mp3->FileNames->Length; ++i)
				{
					
					String^ name = openFileDialog_mp3->FileNames[i];

					MP3* mp3 = new MP3(
						msclr::interop::marshal_as<std::string>(name)
						);

					ListViewItem^ row = gcnew ListViewItem(gcnew String(mp3->mFilename.c_str()));
					row->SubItems->Add(gcnew String(mp3->mArtist.c_str()));
					row->SubItems->Add(gcnew String(mp3->mTitle.c_str()));
					row->SubItems->Add(gcnew String(mp3->mAlbum.c_str()));
					row->SubItems->Add(gcnew String(mp3->mGenre.c_str()));

					listView_Mp3->Items->Add(row);

					delete mp3;

				}
			 }
		 }
};
}

