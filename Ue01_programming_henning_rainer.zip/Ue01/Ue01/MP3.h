#pragma once

using namespace std;

class MP3
{
public:
	MP3(const string& filename);
	~MP3(void);
	
	string mFilename;
	string mTitle;
	string mArtist;
	string mAlbum;
	string mGenre;
};
