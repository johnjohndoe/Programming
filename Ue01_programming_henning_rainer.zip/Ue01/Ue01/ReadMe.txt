========================================================================
    ANWENDUNG: Ue01-Projekt�bersicht
========================================================================

Diese Ue01-Anwendung wurde vom Anwendungs-Assistenten f�r Sie erstellt.  

Diese Datei enth�lt eine Zusammenfassung dessen, was Sie in jeder der Dateien
finden, aus denen Ihre Ue01-Anwendung besteht.

Ue01.vcproj
    Dies ist die Hauptprojektdatei f�r VC++-Projekte, die mit dem Anwendungs-
    Assistenten generiert werden. 
    Sie enth�lt Informationen �ber die Version von Visual C++, in der die Datei 
    generiert wurde, sowie �ber die Plattformen, Konfigurationen und 
    Projektfeatures, die im Anwendungs-Assistenten ausgew�hlt wurden.

Ue01.cpp
    Dies ist die Hauptquelldatei der Anwendung.
    Enth�lt den Code zum Anzeigen des Formulars.

Form1.h
    Enh�lt die Implementierung der Formularklasse und der InitializeComponent()-Funktion.

AssemblyInfo.cpp
    Enth�lt benutzerdefinierte Attribute zum �ndern von Assemblymetadaten.

/////////////////////////////////////////////////////////////////////////////
Weitere Standarddateien:

StdAfx.h, StdAfx.cpp
    Diese Dateien werden verwendet, um eine vorkompilierte Headerdatei
    (PCH-Datei) mit dem Namen "Ue01.pch und eine 
    vorkompilierte Typendatei mit dem Namen "StdAfx.obj" zu erstellen.

/////////////////////////////////////////////////////////////////////////////
